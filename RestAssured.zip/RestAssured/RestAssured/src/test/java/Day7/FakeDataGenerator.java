package Day7;

import com.github.javafaker.Faker;

public class FakeDataGenerator {
	
	void testGenerateDummyData() {
		
		Faker fakedata=new Faker();
		
		String fullname = fakedata.name().fullName();
		String firstName = fakedata.name().firstName();
		String lastName = fakedata.name().lastName();
		
		String username = fakedata.name().username();
		String password = fakedata.internet().password();
		
		String phoneno= fakedata.phoneNumber().cellPhone();
		String email = fakedata.internet().safeEmailAddress();
		
		System.out.println("Full name: "+fullname);
		System.out.println("First name: "+firstName);
		System.out.println("Last name: "+lastName);
		System.out.println("Username: "+username);
		System.out.println("Password: "+password);
		System.out.println("Phone no: "+phoneno);
		System.out.println("Email: "+email);
		
	}

}
