package Day3;


import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.response.Response;


public class CookiesDemo {
	
//	@Test(priority = 1)
	void testCookies() {
		
		given()
		
		.when()
			.get("https://www.google.com")
		
		.then()
			.cookie("AEC", "AUEFqZfuRFOd1b4IYZgFVXSrq-MKFh-Q_7aHZUSCzbyU59Z0GZqQvtIlnw")
			.log().all();
		
	}
	
	@Test(priority = 2)
	void getCookiesInfo() {
		
		Response res=given()
		
		.when()
			.get("https://www.google.com");
		
		//get Single response data
//		String cookie_value=res.getCookie("AEC");
//		System.out.println("Value of AEC is ======>"+cookie_value);
		
		//get all cookies info
		Map<String, String> cookies_value=res.getCookies();
//		System.out.println(cookies_value.keySet());  // o/p : [1P_JAR, AEC, NID]
		
		for(String k:cookies_value.keySet()) {
			
			String value=res.getCookie(k);
			System.out.println(k+"         "+value);
		}
		
	}

}
