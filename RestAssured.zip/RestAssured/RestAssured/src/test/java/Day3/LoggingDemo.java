package Day3;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class LoggingDemo {

	
	@Test(priority = 1)
	void testLogs() {
		given()
		
		.when()
			.get("https://reqres.in/api/users?page=2")
		
		.then()
			//.log().all(); // it will give the whole info of response
			//.log().body();  // it will give info of body response only
			//.log().cookies(); // it will give info of cookies info only
			.log().headers();  // it will give info of headers info only
	}
}
