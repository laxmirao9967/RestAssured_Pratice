package Day6;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

//POJO ----Serialization --->JSON object -----> Deserialization----->POJO


public class SerializationDeserialization {
	
	//POJO------> JSON(Serialization)
//		@Test(priority = 1)
		void convertPOJOToJSON() throws JsonProcessingException {
			
			//Created a java obect using a POJO class
			
			StudentPOJO stuobj = new StudentPOJO();   //POJO class
			stuobj.setName("Scott");
			stuobj.setLocation("France");
			stuobj.setPhone("123456");
			String coursesArr[] = {"C","C++"};
			stuobj.setCourses(coursesArr);
			
			//Convert java object --->json object (serialization)
			ObjectMapper objMapper = new ObjectMapper();
			
			String jsonData = objMapper.writerWithDefaultPrettyPrinter().writeValueAsString(stuobj);
			System.out.println(jsonData);
			
		}
		
		//JSON------> POJO(De-Serialization)
		@Test(priority = 2)
		void convertJSONToPOJO() throws JsonProcessingException {
			
			String jsonData="{\r\n"
					+ "  \"location\" : \"France\",\r\n"
					+ "  \"phone\" : \"123456\",\r\n"
					+ "  \"courses\" : [ \"C\", \"C++\" ],\r\n"
					+ "  \"name\" : \"Scott\"\r\n"
					+ "}";
			
			//Convert json object --->pojo object (de-serialization)
			ObjectMapper objMapper = new ObjectMapper();
			
			StudentPOJO stu = objMapper.readValue(jsonData, StudentPOJO.class); //convert Json to POJO
			System.out.println("Name: "+ stu.getName());
			System.out.println("Location: "+ stu.getLocation());
			System.out.println("Phone number: "+ stu.getPhone());
			System.out.println("Courses: "+ stu.getCourses()[0]);
			System.out.println("Courses: "+ stu.getCourses()[1]);
			
		}
		

}
