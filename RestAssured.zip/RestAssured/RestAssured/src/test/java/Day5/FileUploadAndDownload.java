package Day5;


import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.File;

import org.testng.annotations.Test;

public class FileUploadAndDownload {
	
	@Test(priority = 1)
	void singleFileUpload() {
		
		File myfile = new File("D:\\CV_Laxmi\\API Testing\\Test1.txt");
		
		given()
			.multiPart("file", myfile)  	//As it is the important statement like as we used in postman i.e form-data
			.contentType("multipart/form-data")
		
		.when()
			.post("http://localhost:8080/uploadFile")
		
		.then()
			.statusCode(200)
			.body("fileName", equalTo("Test1.txt"))
			.log().all();
	}
	
//	@Test(priority = 2)
	void multipleFileUpload() {
		
		File myfile1 = new File("D:\\CV_Laxmi\\API Testing\\Test1.txt");
		File myfile2 = new File("D:\\CV_Laxmi\\API Testing\\Test2.txt");
		
		given()
			.multiPart("files", myfile1)  	//As it is the important statement like as we used in postman i.e form-data
			.multiPart("files", myfile2)
			.contentType("multipart/form-data")
		
		.when()
			.post("http://localhost:8080/uploadMultipleFiles")
		
		.then()
			.statusCode(200)
			.body("[0].fileName", equalTo("Test1.txt"))
			.body("[1].fileName", equalTo("Test2.txt"))
			.log().all();
	}
	
	@Test(priority = 3)
	void fileDownload() {
		
		given()
		
		.when()
			.get("http://localhost:8080/downloadFile/Test1.txt")
			
		.then()
			.statusCode(200)
			.log().body();
		
	}

}
